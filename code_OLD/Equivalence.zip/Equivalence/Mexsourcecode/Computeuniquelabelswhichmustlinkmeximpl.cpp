/* Mex impelmentation of Computeuniquelabelswhichmustlinkmex
 * Usage :
 *
 * mex -largeArrayDims Computeuniquelabelswhichmustlinkmeximpl.cpp 
 * 
 *Command to execute:
 *
 * uniquelabelswhichmustlink=Computeuniquelabelswhichmustlinkmeximpl(remappedlabels,labelledleveltmp,numberofsuperpixels,maxnewlabelsalreadyassigned); *
 */

/* INCLUDES: */
#include "mex.h"
#include "matrix.h"
#include "math.h"
#include "float.h"
#include "stdlib.h"


 
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{
   /* DECLARATIONS: */
    double  *uniquelabelswhichmustlink ,*remappedlabels, *labelledleveltmp,*numberofsuperpixels, *maxnewlabelsalreadyassigned;
    mwSize i, j, numelremappedlabels, maxnewlabelsalreadyassignedmwsize, numbersuperpixelsmwsize;
    double id;

    /*Read input and output*/
    remappedlabels                       = mxGetPr(prhs[0]);
    labelledleveltmp                     = mxGetPr(prhs[1]);
    numberofsuperpixels                  = mxGetPr(prhs[2]);
    maxnewlabelsalreadyassigned          = mxGetPr(prhs[3]);
    
    numelremappedlabels = mxGetNumberOfElements(prhs[0]);
    maxnewlabelsalreadyassignedmwsize=(mwSize)(*maxnewlabelsalreadyassigned);
    numbersuperpixelsmwsize=(mwSize)(*numberofsuperpixels);
    
    
    
    /* Initialize output */
    plhs[0] = mxCreateDoubleMatrix(1, numbersuperpixelsmwsize, mxREAL);
    if (plhs[0] == NULL)
        mexErrMsgTxt("Could not create matrix.\n");
    
    uniquelabelswhichmustlink            = mxGetPr(plhs[0]);
    
    // mxDestroyArray(plhs[0]); _unnecessary as the array is output
    // numeluniquelabelswhichmustlink = mxGetNumberOfElements(plhs[0]);

    
    
    for(j=0;j< numelremappedlabels;j++)
    {
        id = remappedlabels[j];
        i = (mwSize) id;
        if((i>=1) && (i<= maxnewlabelsalreadyassignedmwsize))
        {
            uniquelabelswhichmustlink[((mwSize) labelledleveltmp[j])-1] = id; // labelledleveltmp is in matlab notations
        }
    }  
}
    
    
  