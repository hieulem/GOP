/*
 * to compile:
 *
 * mex Reducenewaffinityequivalentgraphmex.cpp
 * 
 * Notes: assume each label is taken so numlabels=maxlabels
 *        printthetext must be boolean
 */



#include "stdio.h"
#include "stdlib.h"
#include "float.h"

#include "math.h"                                       
#include <iostream> //cout
#include <map> //map
#include <utility> //pair

#include "mex.h"

using namespace std;



void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
    
    if (nrhs < 4) mexErrMsgTxt("INPUT:  ii, jj, vv, labels [, printthetxt] ");
    if (nlhs < 3) mexErrMsgTxt("OUTPUT: ii, jj, vv , labelcount ");
    
    
    
    double *ii = mxGetPr( prhs[0]);
    double *jj = mxGetPr( prhs[1]);
    double *vv = mxGetPr( prhs[2]);
    double *mustlinklabelstypedouble = mxGetPr( prhs[3]);
    
    bool printthetext=false;
    if (nrhs>4)
    {
        bool *tmpprinttext = (bool *) mxGetPr( prhs[4]) ;
        printthetext= bool ( *tmpprinttext );
    }
    
    
    
    int numsuperpixels = mxGetNumberOfElements( prhs[3]); //compute this from mustlinklabelstypedouble
    if (printthetext)   cout<<"Number of superpixels "<<numsuperpixels<<endl;
    
    
    
    //cast labels to int and count them
    //IMPORTANT: assume each label is taken so numlabels=maxlabels
    int numlabels=0;
    int *mustlinklabels;
    mustlinklabels= new int[numsuperpixels];
    for (int i=0; i<numsuperpixels; i++)
    {
        mustlinklabels[i] = static_cast<int>(mustlinklabelstypedouble[i]);
	    numlabels = max(mustlinklabels[i], numlabels); 
    }
    if (printthetext)   cout<<"Number of labels "<<numlabels<<endl;

    //Define and initialize a label count variable
    int *labelcount = new int [numlabels];
    for (int i=0; i<numlabels; i++)
    {
        labelcount[i]=static_cast<int>(0);
    }
    
    //Count how many superpixels are grouped into the labels
    for (int i=0; i<numsuperpixels; i++)
    {
        labelcount[ mustlinklabels[i]-1 ] +=1;
    }


    
    int numberofaddinities = mxGetNumberOfElements( prhs[0]);
    if (printthetext)   cout<<"Number of affinities "<<numberofaddinities<<endl;
    
    
    
    //Define and initialize a volume double array (missing the internal volume) to use for the normalization
    double *semilabelvolume = new double [numlabels];
    for (int i=0; i<numlabels; i++)
    {
        semilabelvolume[i]=static_cast<double>(0.0);
    }

    //Compute the reduced affinity (map)
    map<pair<int,int>, double> ramatrix;
    for (int i=0; i<numberofaddinities; i++)
    {
        int currentlabelone=( mustlinklabels[static_cast<int>(ii[i]-1)] - 1 );
        int currentlabeltwo=( mustlinklabels[static_cast<int>(jj[i]-1)] - 1 );
        pair<int,int> pos( currentlabelone , currentlabeltwo );
        if (pos.first != pos.second)
        {
          semilabelvolume[ currentlabelone ] += static_cast<double>(vv[i]);
          ramatrix[pos]+=static_cast<double>(vv[i]);
        }
        else
        {
          ramatrix[pos]+=static_cast<double>(vv[i])/static_cast<double>(labelcount[pos.first]);
        }
    }
    
    
    
    for (int i=0; i<numlabels; i++)
    {
      std::pair<int,int> pos(i,i);
      ramatrix[pos]-= (static_cast<double>(labelcount[i]-1)) * semilabelvolume[i] / static_cast<double>(labelcount[i]) ;
    }
    
    
    
    //Output the reduced affinity (ii,jj,vv)
    int nnz= (int) ramatrix.size() ;
    if (printthetext)   cout<<"Number of nonzero entries "<<nnz<<endl;
    
    plhs[0] = mxCreateDoubleMatrix(nnz,1,mxREAL);
    plhs[1] = mxCreateDoubleMatrix(nnz,1,mxREAL);
    plhs[2] = mxCreateDoubleMatrix(nnz,1,mxREAL);
    double* iinew = mxGetPr(plhs[0]); //col index
    double* jjnew = mxGetPr(plhs[1]); //row index
    double* vvnew = mxGetPr(plhs[2]); //values
    int ct = 0;
    for(std::map<std::pair<int,int>, double>::iterator ii=ramatrix.begin();ii!=ramatrix.end(); ++ii)
      {
        std::pair<int,int> pos=(*ii).first;
        jjnew[ct]=static_cast<double>(pos.first +1);
        iinew[ct]=static_cast<double>(pos.second +1);
        vvnew[ct]=(*ii).second;
        ct++;
      }
    if (printthetext)   cout<<"Number of nonzero entries processed "<<ct<<endl;
    
    //Return label count
    plhs[3] = mxCreateDoubleMatrix(numlabels,1,mxREAL);
    double* labelcountout = mxGetPr(plhs[3]);
    for (int i=0; i<numlabels; i++)
        labelcountout[i]=static_cast<double>(labelcount[i]);
    
    
    
    //Clean up
    ramatrix.clear();
    delete [] mustlinklabels;
    delete [] labelcount;
    delete [] semilabelvolume;

    
    
}





